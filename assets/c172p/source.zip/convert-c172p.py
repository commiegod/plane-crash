# GPL-2.0: conversion tool for the c172p-team aircraft assets.
from pathlib import Path
import json,shlex,struct,math,re,zipfile
import numpy as np
from PIL import Image
import xml.etree.ElementTree as ET
ROOT=Path(__file__).parent/'c172p';OUT=Path(__file__).parent.parent/'site/assets/c172p';OUT.mkdir(exist_ok=True)
gltf={'asset':{'version':'2.0','generator':'Flight Simulator AC3D converter'},'scene':0,'scenes':[{'nodes':[]}],'nodes':[],'meshes':[],'materials':[],'textures':[],'images':[],'samplers':[{'magFilter':9729,'minFilter':9987,'wrapS':10497,'wrapT':10497}],'accessors':[],'bufferViews':[],'buffers':[{}]};binary=bytearray();textures={};sources=set();materials={}
def acc(values,typ):
 a=np.asarray(values,dtype='<f4');binary.extend(b'\0'*((-len(binary))%4));offset=len(binary);data=a.tobytes();binary.extend(data);v=len(gltf['bufferViews']);gltf['bufferViews'].append({'buffer':0,'byteOffset':offset,'byteLength':len(data)})
 item={'bufferView':v,'componentType':5126,'count':len(a),'type':typ}
 if typ=='VEC3':item.update(min=a.min(axis=0).tolist(),max=a.max(axis=0).tolist())
 gltf['accessors'].append(item);return len(gltf['accessors'])-1

def texture(path):
 path=path.resolve()
 if path in textures:return textures[path]
 if not path.exists():return None
 sources.add(path);im=Image.open(path);im.thumbnail((2048,2048));name=f'{len(textures):02d}-{path.stem}.png';im.save(OUT/name,optimize=True)
 i=len(gltf['images']);gltf['images'].append({'uri':name});gltf['textures'].append({'source':i,'sampler':0});textures[path]=i;return i

def material(m,tex):
 key=(json.dumps(m),str(tex));
 if key in materials:return materials[key]
 alpha=1-m.get('trans',0);rgb=m.get('rgb',[.8,.8,.8]);t=texture(tex) if tex else None
 mat={'name':m['name'],'pbrMetallicRoughness':{'baseColorFactor':([1,1,1] if t is not None else rgb)+[alpha],'metallicFactor':.05,'roughnessFactor':.65},'doubleSided':True}
 if t is not None:mat['pbrMetallicRoughness']['baseColorTexture']={'index':t}
 if alpha<1:mat['alphaMode']='BLEND'
 idx=len(gltf['materials']);gltf['materials'].append(mat);materials[key]=idx;return idx

def ac(path,parent=None,texroot=None,prefix=''):
 path=path.resolve();sources.add(path);lines=path.read_text(errors='replace').splitlines();i=1;mats=[]
 while i<len(lines) and lines[i].startswith('MATERIAL'):
  a=shlex.split(lines[i]);m={'name':a[1]}
  for key in ['rgb','trans']:
   k=a.index(key);m[key]=float(a[k+1]) if key=='trans' else list(map(float,a[k+1:k+4]))
  mats.append(m);i+=1
 def obj(parent):
  nonlocal i
  assert lines[i].startswith('OBJECT');i+=1;n={'name':'object'};verts=[];surfs=[];tex=None;crease=45
  while i<len(lines):
   a=shlex.split(lines[i]);i+=1
   if not a:continue
   key=a[0]
   if key=='name':n['name']=prefix+a[1]
   elif key=='loc':n['translation']=list(map(float,a[1:]))
   elif key=='rot':
    r=np.eye(4);r[:3,:3]=np.array(list(map(float,a[1:]))).reshape(3,3);n['matrix']=r.T.flatten().tolist()
   elif key=='texture':tex=(texroot or path.parent)/a[1]
   elif key=='crease':crease=float(a[1])
   elif key=='data':i+=1
   elif key=='numvert':count=int(a[1]);verts=np.array([list(map(float,x.split())) for x in lines[i:i+count]]);i+=count
   elif key=='numsurf':
    for _ in range(int(a[1])):
     assert lines[i].startswith('SURF');flag=int(lines[i].split()[1],0);i+=1;mi=0
     if lines[i].startswith('mat'):mi=int(lines[i].split()[1]);i+=1
     count=int(lines[i].split()[1]);i+=1;refs=[list(map(float,x.split())) for x in lines[i:i+count]];i+=count
     if flag&15==0:surfs.append((mi,refs))
   elif key=='kids':
    idx=len(gltf['nodes']);gltf['nodes'].append(n)
    if parent is None:gltf['scenes'][0]['nodes'].append(idx)
    else:gltf['nodes'][parent].setdefault('children',[]).append(idx)
    invisible=any(x in n['name'].lower() for x in ['hotspot','fastprop','propellercowlplugs','courtesyon','wing_1ledge','wing_1redge'])
    groups={}
    if not invisible:
     normals=np.zeros_like(verts)
     for mi,refs in surfs:
      ids=[int(r[0]) for r in refs]
      for j in range(1,len(ids)-1):
       ia,ib,ic=ids[0],ids[j],ids[j+1];norm=np.cross(verts[ib]-verts[ia],verts[ic]-verts[ia]);norm/=max(1e-12,np.linalg.norm(norm))
       for q in [ia,ib,ic]:normals[q]+=norm
     if len(normals):normals/=np.maximum(1e-12,np.linalg.norm(normals,axis=1))[:,None]
     for mi,refs in surfs:
      if mats[mi].get('trans',0)>.99:continue
      g=groups.setdefault(mi,[[],[],[]])
      for j in range(1,len(refs)-1):
       for ref in [refs[0],refs[j],refs[j+1]]:
        q=int(ref[0]);g[0].append(verts[q]);g[1].append(normals[q]);g[2].append([ref[1],1-ref[2]])
     primitives=[]
     for mi,(p,norm,uv) in groups.items():
      if p:primitives.append({'attributes':{'POSITION':acc(p,'VEC3'),'NORMAL':acc(norm,'VEC3'),'TEXCOORD_0':acc(uv,'VEC2')},'material':material(mats[mi],tex)})
     if primitives:n['mesh']=len(gltf['meshes']);gltf['meshes'].append({'name':n['name'],'primitives':primitives})
    for _ in range(int(a[1])):obj(idx)
    return idx
 return obj(parent)

def resolve(path,base):return (ROOT/path[len('Aircraft/c172p/'):] if path.startswith('Aircraft/c172p/') else base/path).resolve()
def xml(path,parent=None,offset=None,depth=0):
 if depth>8 or not path.exists():return
 sources.add(path.resolve())
 try:r=ET.parse(path).getroot()
 except ET.ParseError:return
 n={'name':path.stem};idx=len(gltf['nodes']);gltf['nodes'].append(n)
 if parent is None:gltf['scenes'][0]['nodes'].append(idx)
 else:gltf['nodes'][parent].setdefault('children',[]).append(idx)
 if offset is not None:
  def f(k):return float(offset.findtext(k,'0'))
  # FlightGear XML (aft, right, up) to AC3D (aft, up, left).
  n['translation']=[f('x-m'),f('z-m'),-f('y-m')]
  angle=f('heading-deg')*math.pi/180
  if angle:n['rotation']=[0,math.sin(angle/2),0,math.cos(angle/2)]
 p=r.findtext('path');tr=r.findtext('texture-path');tr=resolve(tr,path.parent) if tr else None
 if p:
  file=resolve(p,path.parent)
  if file.suffix=='.ac' and file.exists():ac(file,idx,tr,prefix=path.stem+'/')
 for model in r.findall('model'):
  p=model.findtext('path','')
  if any(x in p for x in ['/Effects/','garmin196','mag-compass-float','digital-clock','gear-ctl']):continue
  if p.endswith('.xml'):xml(resolve(p,path.parent),idx,model.find('offsets'),depth+1)
 return idx
ac(ROOT/'Models/c172-common.ac')
xml(ROOT/'Models/Interior/Panel/c172p-panel/c172p.xml')
gltf['buffers'][0]['byteLength']=len(binary);js=json.dumps(gltf,separators=(',',':')).encode();js+=b' '*((-len(js))%4);binary.extend(b'\0'*((-len(binary))%4));(OUT/'c172p.glb').write_bytes(struct.pack('<III',0x46546c67,2,12+8+len(js)+8+len(binary))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(binary),0x004e4942)+binary)
with zipfile.ZipFile(OUT/'source.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sources:z.write(p,p.relative_to(ROOT))
 for f in ['LICENSE','README.md','Thanks']:z.write(ROOT/f,f)
 z.write(__file__,'convert-c172p.py')
(OUT/'COPYING.txt').write_text((ROOT/'LICENSE').read_text())
print('meshes',len(gltf['meshes']),'textures',len(textures),'GLB MB',len(binary)/1e6)
