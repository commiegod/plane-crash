from pathlib import Path
import json,struct,zipfile,xml.etree.ElementTree as E
from PIL import Image
root=Path(__file__).resolve().parent/'b727';out=root.parent.parent/'site/assets/b727';p=out/'b727.glb';b=p.read_bytes();n=struct.unpack_from('<I',b,12)[0];g=json.loads(b[20:20+n]);binary=b[28+n:];names={x.get('name') for x in g['nodes']}
for mat in g['materials']:
 t=mat.get('pbrMetallicRoughness',{}).get('baseColorTexture')
 if t:
  im=Image.open(out/g['images'][g['textures'][t['index']]['source']]['uri'])
  if 'A' in im.getbands() and im.getextrema()[-1][0]<255 and mat.get('alphaMode')!='BLEND':mat['alphaMode']='MASK';mat['alphaCutoff']=.35
anims=[]
for path in (root/'Models').rglob('*.xml'):
 try:r=E.parse(path).getroot()
 except E.ParseError:continue
 for a in r.findall('animation'):
  prop=a.findtext('property','');kind=a.findtext('type');ns=[path.stem+'/'+o.text for o in a.findall('object-name')]
  if kind not in ['rotate','translate','textranslate'] or not ns or not all(x in names for x in ns):continue
  if 'flap-pos-norm' in prop:prop='game/flaps'
  elif prop.startswith('gear/gear[') and prop.endswith('/position-norm'):prop='game/gear'
  elif not any(x in prop for x in ['speed-kt','altitude-ft','speed-fpm','heading-deg','roll-deg','pitch-deg','/n1','/n2']):continue
  if prop.startswith('instrumentation/nav/'):continue
  def vec(tag,suffix=''):
   e=a.find(tag);return [float(e.findtext(k+suffix,'0')) if e is not None else 0 for k in ['x','z','y']][:2]+[-float(e.findtext('y'+suffix,'0')) if e is not None else 0]
  axis=vec('axis');center=vec('center','-m')
  if a.find('axis/x1-m') is not None:
   center=vec('axis','1-m');end=vec('axis','2-m');axis=[v-center[i] for i,v in enumerate(end)]
  anims.append(dict(names=ns,kind=kind,property=prop,sourceFrame=path.stem,step=float(a.findtext('step','0')),factor=float(a.findtext('factor','1')),offset=float(a.findtext('offset-deg','0')),axis=axis,center=center,table=[[float(e.findtext('ind')),float(e.findtext('dep'))] for e in a.findall('interpolation/entry')]))
(out/'instruments.json').write_text(json.dumps(anims,separators=(',',':')))
js=json.dumps(g,separators=(',',':')).encode();js+=b' '*((-len(js))%4);p.write_bytes(struct.pack('<III',0x46546c67,2,28+len(js)+len(binary))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(binary),0x004e4942)+binary)
with zipfile.ZipFile(out/'source.zip','a',zipfile.ZIP_DEFLATED) as z:z.write(__file__,'prepare-b727.py')
print('bindings',len(anims),'gear',sum(a['property']=='game/gear' for a in anims),'flaps',sum(a['property']=='game/flaps' for a in anims))
