# GPL-2.0: lossless vertex indexing and WebP texture conversion for aircraft glTF.
from pathlib import Path
import sys,struct,json,numpy as np,zipfile
from PIL import Image
p=Path(sys.argv[1]);b=p.read_bytes();n=struct.unpack_from('<I',b,12)[0];g=json.loads(b[20:20+n]);data=b[28+n:];binary=bytearray();accessors=[];views=[]
def add(a,typ,component):
 binary.extend(b'\0'*((-len(binary))%4));off=len(binary);binary.extend(a.tobytes());v=len(views);views.append({'buffer':0,'byteOffset':off,'byteLength':a.nbytes});d={'bufferView':v,'componentType':component,'count':len(a),'type':typ}
 if typ=='VEC3':d.update(min=a.min(0).tolist(),max=a.max(0).tolist())
 accessors.append(d);return len(accessors)-1
for mesh in g['meshes']:
 for primitive in mesh['primitives']:
  arrays=[];names=list(primitive['attributes']);widths=[]
  for name in names:
   a=g['accessors'][primitive['attributes'][name]];v=g['bufferViews'][a['bufferView']];w={'VEC2':2,'VEC3':3}[a['type']];widths.append(w);arrays.append(np.frombuffer(data,dtype='<f4',count=a['count']*w,offset=v.get('byteOffset',0)+a.get('byteOffset',0)).reshape(-1,w))
  unique,index=np.unique(np.concatenate(arrays,axis=1),axis=0,return_inverse=True);start=0
  for name,w in zip(names,widths):primitive['attributes'][name]=add(np.ascontiguousarray(unique[:,start:start+w],dtype='<f4'),'VEC'+str(w),5126);start+=w
  primitive['indices']=add(index.astype('<u2' if len(unique)<65536 else '<u4'),'SCALAR',5123 if len(unique)<65536 else 5125)
for img in g['images']:
 old=p.parent/img['uri'];new=old.with_suffix('.webp');Image.open(old).save(new,'WEBP',quality=88,method=6);img['uri']=new.name
binary.extend(b'\0'*((-len(binary))%4));g['bufferViews']=views;g['accessors']=accessors;g['buffers']=[{'byteLength':len(binary)}];js=json.dumps(g,separators=(',',':')).encode();js+=b' '*((-len(js))%4);p.write_bytes(struct.pack('<III',0x46546c67,2,28+len(js)+len(binary))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(binary),0x004e4942)+binary)
with zipfile.ZipFile(p.parent/'source.zip','a',zipfile.ZIP_DEFLATED) as z:z.write(__file__,'optimize-aircraft.py')
for img in g['images']:(p.parent/Path(img['uri']).with_suffix('.png')).unlink(missing_ok=True)
print('Indexed GLB',p.stat().st_size/1e6,'MB; texture MB',sum(f.stat().st_size for f in p.parent.glob('*.webp'))/1e6)
