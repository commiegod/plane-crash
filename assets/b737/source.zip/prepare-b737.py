# GPL-2.0: prepare Boeing 737-800 materials and existing Delta/American/United artwork.
from pathlib import Path
from PIL import Image
import json,struct,zipfile
base=Path(__file__).resolve().parent.parent;p=base/'site/assets/b737/b737.glb';b=p.read_bytes();n=struct.unpack_from('<I',b,12)[0];g=json.loads(b[20:20+n]);binary=b[28+n:]
for m in g['materials']:
 t=m['pbrMetallicRoughness'].get('baseColorTexture')
 if t is None:continue
 path=p.parent/g['images'][g['textures'][t['index']]['source']]['uri'];im=Image.open(path)
 if 'A' in im.getbands() and im.getchannel('A').getextrema()[0]<250:m['alphaMode']='MASK';m['alphaCutoff']=.5
 if '737-800' in path.name:m['extras']={'paintSlot':'fuselage'}
js=json.dumps(g,separators=(',',':')).encode();js+=b' '*((-len(js))%4);p.write_bytes(struct.pack('<III',0x46546c67,2,28+len(js)+len(binary))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(binary),0x004e4942)+binary)
with zipfile.ZipFile(p.parent/'source.zip','a',zipfile.ZIP_DEFLATED) as z:
 for code in ['DAL','AAL','UAL']:
  src=base/'work/b737/Models/Liveries-800'/(code+'.png');im=Image.open(src);im.thumbnail((2048,2048));im.save(p.parent/(code+'-fuselage.webp'),'WEBP',quality=90,method=6);z.write(src,src.relative_to(base/'work/b737'))
 z.write(__file__,'prepare-b737.py')
(p.parent/'instruments.json').write_text('[]')
