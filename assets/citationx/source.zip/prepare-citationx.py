# GPL-2.0: Flight Simulator Citation X adaptation.
from pathlib import Path
import json,struct,zipfile
from PIL import Image
root=Path(__file__).resolve().parent/'citationx-gpl';out=root.parent.parent/'site/assets/citationx';p=out/'citationx.glb';b=p.read_bytes();n=struct.unpack_from('<I',b,12)[0];g=json.loads(b[20:20+n]);binary=b[28+n:]
for mat in g['materials']:
 t=mat.get('pbrMetallicRoughness',{}).get('baseColorTexture')
 if t:
  uri=g['images'][g['textures'][t['index']]['source']]['uri'];im=Image.open(out/uri)
  if 'A' in im.getbands() and im.getextrema()[-1][0]<255 and mat.get('alphaMode')!='BLEND':mat['alphaMode']='MASK';mat['alphaCutoff']=.35
(out/'instruments.json').write_text('[]')
js=json.dumps(g,separators=(',',':')).encode();js+=b' '*((-len(js))%4);p.write_bytes(struct.pack('<III',0x46546c67,2,28+len(js)+len(binary))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(binary),0x004e4942)+binary)
with zipfile.ZipFile(out/'source.zip','a',zipfile.ZIP_DEFLATED) as z:z.write(__file__,'prepare-citationx.py')
