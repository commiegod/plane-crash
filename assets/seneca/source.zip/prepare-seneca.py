# GPL-2.0-or-later: Flight Simulator Seneca adaptation.
from pathlib import Path
import json,struct,zipfile,xml.etree.ElementTree as E
from PIL import Image
root=Path(__file__).resolve().parent/'seneca';out=root.parent.parent/'site/assets/seneca';p=out/'seneca.glb';b=p.read_bytes();n=struct.unpack_from('<I',b,12)[0];g=json.loads(b[20:20+n]);binary=b[28+n:]
for mat in g['materials']:
 t=mat.get('pbrMetallicRoughness',{}).get('baseColorTexture')
 if t:
  im=Image.open(out/g['images'][g['textures'][t['index']]['source']]['uri'])
  if 'A' in im.getbands() and im.getextrema()[-1][0]<255 and mat.get('alphaMode')!='BLEND':mat['alphaMode']='MASK';mat['alphaCutoff']=.35
names={n.get('name') for n in g['nodes']};anims=[];included=set()
for path in root.rglob('*.xml'):
 try:r=E.parse(path).getroot()
 except E.ParseError:continue
 prefixes=['RPMLeft','RPMRight'] if path.stem=='RPM' else [path.stem]
 for prefix in prefixes:
  for a in r.findall('animation'):
   prop=a.findtext('property','');pe=a.find('property');kind=a.findtext('type')
   if pe is not None and pe.get('alias'):prop=r.findtext('params/'+pe.get('alias').split('/')[-1],'')
   if prefix=='RPMRight':prop=prop.replace('engine[0]','engine[1]')
   if kind not in ['rotate','translate'] or not any(x in prop for x in ['speed-kt','altitude-ft','speed-fpm','heading-deg','roll-deg','pitch-deg','/rpm']):continue
   ns=[prefix+'/'+o.text for o in a.findall('object-name')]
   if not ns or not all(n in names for n in ns):continue
   def vec(tag,suffix=''):
    e=a.find(tag);v=[float(e.findtext(k+suffix,'0')) if e is not None else 0 for k in ['x','y','z']];return [v[0],v[2],-v[1]]
   it=a.find('interpolation');entries=[]
   if it is not None:
    if it.get('include'):
     inc=path.parent/it.get('include');it=E.parse(inc).getroot();included.add(inc)
    entries=[[float(e.findtext('ind')),float(e.findtext('dep'))] for e in it.findall('entry')]
   suffix='-deg' if kind=='rotate' else '-m'
   anims.append(dict(names=ns,kind=kind,property=prop,factor=float(a.findtext('factor','1')),offset=float(a.findtext('offset-deg','0')),axis=vec('axis'),center=vec('center','-m'),min=float(a.findtext('min'+suffix,a.findtext('min','-1e9'))),max=float(a.findtext('max'+suffix,a.findtext('max','1e9'))),table=entries))
(out/'instruments.json').write_text(json.dumps(anims))
js=json.dumps(g,separators=(',',':')).encode();js+=b' '*((-len(js))%4);p.write_bytes(struct.pack('<III',0x46546c67,2,28+len(js)+len(binary))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(binary),0x004e4942)+binary)
with zipfile.ZipFile(out/'source.zip','a',zipfile.ZIP_DEFLATED) as z:
 z.write(__file__,'prepare-seneca.py')
 for inc in included:z.write(inc,str(inc.relative_to(root)))
print('Seneca bindings',len(anims))
