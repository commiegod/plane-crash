from pathlib import Path
import json,struct,zipfile,xml.etree.ElementTree as ET
from PIL import Image
root=Path(__file__).resolve().parent/'dc9';out=root.parent.parent/'site/assets/dc9';p=out/'dc9.glb';b=p.read_bytes();n=struct.unpack_from('<I',b,12)[0];g=json.loads(b[20:20+n]);binary=b[28+n:]
for mat in g['materials']:
 if mat.get('name')=='MatteBlack':mat['pbrMetallicRoughness']['baseColorFactor']=[.035,.035,.035,1];mat['pbrMetallicRoughness']['roughnessFactor']=.95
 t=mat.get('pbrMetallicRoughness',{}).get('baseColorTexture')
 if t:
  uri=g['images'][g['textures'][t['index']]['source']]['uri'];im=Image.open(out/uri)
  if 'A' in im.getbands() and im.getextrema()[-1][0]<255 and mat.get('alphaMode')!='BLEND':mat['alphaMode']='MASK';mat['alphaCutoff']=.35
  if uri.startswith('00-DAL.'):mat['extras']={'paintSlot':'fuselage'}
# FlightGear glass effects are separate from the AC3D materials. Preserve them explicitly.
for node in g['nodes']:
 if 'mesh' not in node or not any(s in node.get('name','').lower() for s in ['vitre']):continue
 for prim in g['meshes'][node['mesh']]['primitives']:
  mat=json.loads(json.dumps(g['materials'][prim['material']]));mat['name']='glass-'+mat['name'];mat['alphaMode']='BLEND';mat['pbrMetallicRoughness']['baseColorFactor']=[.8,.9,1,.12];prim['material']=len(g['materials']);g['materials'].append(mat)
anims=[];names={n.get('name') for n in g['nodes']}
for path in (root/'Models/Flightdeck').rglob('*.xml'):
 try:r=ET.parse(path).getroot()
 except ET.ParseError:continue
 for a in r.findall('animation'):
  prop=a.findtext('property','');kind=a.findtext('type')
  if kind not in ['rotate','translate','textranslate'] or not any(x in prop for x in ['speed-kt','altitude-ft','speed-fpm','heading-deg','heading-magnetic-deg','roll-deg','pitch-deg','/rpm','/n1','/n2']):continue
  if prop.startswith('instrumentation/nav/'):continue
  ns=[path.stem+'/'+o.text for o in a.findall('object-name')]
  if not ns or not all(n in names for n in ns):continue
  def vec(tag,suffix=''):
   e=a.find(tag);v=[float(e.findtext(k+suffix,'0')) if e is not None else 0 for k in ['x','y','z']];return [v[0],v[2],-v[1]]
  anims.append(dict(names=ns,kind=kind,property=prop,step=float(a.findtext('step','0')),factor=float(a.findtext('factor','1')),offset=float(a.findtext('offset-deg','0')),axis=vec('axis'),center=vec('center','-m'),min=float(a.findtext('min','-1e9')),max=float(a.findtext('max','1e9')),table=[[float(e.findtext('ind')),float(e.findtext('dep'))] for e in a.findall('interpolation/entry')]))
(out/'instruments.json').write_text(json.dumps(anims))
im=Image.open(root/'Models/DAL.png');im.thumbnail((2048,2048));im.save(out/'DAL-fuselage.webp','WEBP',quality=90)
js=json.dumps(g,separators=(',',':')).encode();js+=b' '*((-len(js))%4);p.write_bytes(struct.pack('<III',0x46546c67,2,28+len(js)+len(binary))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(binary),0x004e4942)+binary)
with zipfile.ZipFile(out/'source.zip','a',zipfile.ZIP_DEFLATED) as z:
 z.write(__file__,'prepare-dc9.py');z.write(root/'Models/DAL.png','Models/DAL.png')
print('DC-9 bindings:',len(anims))
